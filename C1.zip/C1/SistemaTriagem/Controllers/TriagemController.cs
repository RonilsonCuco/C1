using Microsoft.AspNetCore.Mvc;
using SistemaTriagem.Models;
using System.Text.Json;

namespace SistemaTriagem.Controllers
{
    public class TriagemController : Controller
    {
        private string caminho = "Data/dados.json";

        // Redireciona a página inicial para o questionário
        public IActionResult Index()
        {
            return RedirectToAction("Questionario");
        }

        // Exibe o questionário
        public IActionResult Questionario()
        {
            // Opções padrão do Washington Group
            ViewBag.Opcoes = new List<(int Valor, string Descricao)>
            {
                (1, "Não, nenhuma dificuldade"),
                (2, "Sim, alguma dificuldade"),
                (3, "Sim, muita dificuldade"),
                (4, "Não consegue de forma alguma")
            };

            return View();
        }

        // Processa o envio do formulário
        [HttpPost]
        public IActionResult Processar(Avaliacao model)
        {
            // Aplica o critério Washington Group
            if (model.Pergunta1 >= 3 || model.Pergunta2 >= 3 || model.Pergunta3 >= 3 ||
                model.Pergunta4 >= 3 || model.Pergunta5 >= 3)
            {
                model.Resultado = "Com deficiência";
            }
            else
            {
                model.Resultado = "Sem deficiência";
            }

            model.DataHora = DateTime.Now;

            Salvar(model);

            return RedirectToAction("Resultado", model);
        }

        // Exibe o resultado individual
        public IActionResult Resultado(Avaliacao model)
        {
            return View(model);
        }

        // Lista todas as avaliações
        public IActionResult PessoasIdentificadas()
        {
            List<Avaliacao> lista = new List<Avaliacao>();

            if (System.IO.File.Exists(caminho))
            {
                string json = System.IO.File.ReadAllText(caminho);
                if (!string.IsNullOrEmpty(json))
                    lista = JsonSerializer.Deserialize<List<Avaliacao>>(json) ?? new List<Avaliacao>();
            }

            return View(lista);
        }

        // Salva o registro em JSON
        private void Salvar(Avaliacao model)
        {
            List<Avaliacao> lista = new List<Avaliacao>();

            if (System.IO.File.Exists(caminho))
            {
                string json = System.IO.File.ReadAllText(caminho);
                if (!string.IsNullOrEmpty(json))
                    lista = JsonSerializer.Deserialize<List<Avaliacao>>(json) ?? new List<Avaliacao>();
            }

            lista.Add(model);

            string novoJson = JsonSerializer.Serialize(lista, new JsonSerializerOptions { WriteIndented = true });
            System.IO.File.WriteAllText(caminho, novoJson);
        }
    }
}