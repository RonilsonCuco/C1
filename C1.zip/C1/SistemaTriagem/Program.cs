var builder = WebApplication.CreateBuilder(args);

// Adiciona suporte a Controllers e Views
builder.Services.AddControllersWithViews();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();
app.UseAuthorization();

// Rota padrão: TriagemController/Index
app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Triagem}/{action=Index}/{id?}");

app.Run();