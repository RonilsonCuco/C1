using System;
using System.Collections.Generic;

namespace SistemaTriagem.Models
{
    public class Avaliacao
    {
        public string? Nome { get; set; }
        public int Pergunta1 { get; set; }
        public int Pergunta2 { get; set; }
        public int Pergunta3 { get; set; }
        public int Pergunta4 { get; set; }
        public int Pergunta5 { get; set; }
        public string? Resultado { get; set; }
        public DateTime DataHora { get; set; }
    }
}